/* ==========================================================================
   MELIA'S iPHONE — EDITABLE STORY CONTENT
   --------------------------------------------------------------------------
   Everything the reader can discover lives in this file. The interface code
   (app.js) never contains story text, so you can change dialogue, dates,
   images and clues here without touching the engine.

   All entries below are the placeholders from the original prototype.
   Nothing here is story canon unless you decide it is.

   IMAGES / AUDIO (all optional, always relative paths, e.g. "assets/x.jpg"):
     CONFIG.wallpaper.lock / .home   lock-screen and home-screen wallpaper
     CONFIG.mapImage                 map picture (Find My, Maps)
     chat.img / contact.img          avatar photo
     message {img:"…"}               photo attachment   {video:"…",duration:"0:12"} video
     message {voice:1, src:"…"}      audio file for a voice message
     album.cover / photo item .src   album cover / the photo itself
     playlist.art                    playlist artwork
   If a path is left out, a neutral placeholder is shown instead.
   ========================================================================== */

const CONFIG = {
  passcode: "280108",
  owner: "Melia Nadya",
  date: "Thursday, 22 October",          // shown on Lock Screen and Home Screen
  dayNumber: "22",                       // number on the Calendar icon
  time: "10:41",                         // the phone's clock (24h, HH:MM). Keep it later than your newest "Today" message.
  weather: { temp: "18°", cond: "Cloudy", place: "London" },
  authorNotes: false,                    // true = show small "placeholder / editor" notes inside the apps
  wallpaper: { lock: "", home: "" },
  mapImage: "",
  libraryAlbum: "Recents",               // the Photos album that is shown as the Library
  notifications: [
    { app: "Messages", title: "Best friend", time: "09:16", body: "Audio Message", open: { app: "messages", chat: "friend" } },
    { app: "Calendar", title: "Reminder", time: "08:41", body: "Seminar reading — check the article", open: { app: "calendar" } }
  ]
};

/* id, name, glyph, icon colour (c), glyph colour (fg), dock:1 = lives in the Dock.
   Home Screen pages are filled automatically in this order, 16 icons per page. */
const APPS = [
  { id: "messages", n: "Messages", g: "●", c: "#1685f8", dock: 1 },
  { id: "phone", n: "Phone", g: "☎", c: "#32c66a", dock: 1 },
  { id: "photos", n: "Photos", g: "✿", c: "#fff", fg: "#e65a8d", dock: 1 },
  { id: "music", n: "Music", g: "♫", c: "#fa3159", dock: 1 },
  { id: "mail", n: "Mail", g: "✉", c: "#1685f8" },
  { id: "calendar", n: "Calendar", g: "·", c: "#fff", fg: "#e34a4a" },   // glyph replaced by CONFIG.dayNumber
  { id: "notes", n: "Notes", g: "▤", c: "#fff", fg: "#b28a32" },
  { id: "wallet", n: "Wallet", g: "▣", c: "#292d36" },
  { id: "facetime", n: "FaceTime", g: "◉", c: "#35c86a" },
  { id: "files", n: "Files", g: "▰", c: "#fff", fg: "#4d8ee8" },
  { id: "safari", n: "Safari", g: "◉", c: "#e9f4ff", fg: "#1685f8" },
  { id: "findmy", n: "Find My", g: "◎", c: "#fff", fg: "#31b86a" },
  { id: "settings", n: "Settings", g: "⚙", c: "#8d929b" },
  { id: "contacts", n: "Contacts", g: "♙", c: "#fff", fg: "#dc8b42" },
  { id: "maps", n: "Maps", g: "⌖", c: "#e8f2e8", fg: "#389a68" },
  { id: "reminders", n: "Reminders", g: "☷", c: "#fff", fg: "#3988e8" },
  { id: "voice", n: "Voice Memos", g: "〰", c: "#fff", fg: "#d65d75" },
  { id: "passwords", n: "Passwords", g: "🔑", c: "#f1c94a", fg: "#493b16" },
  { id: "university", n: "University", g: "U", c: "#263d66" },
  { id: "bank", n: "Banking", g: "£", c: "#173f35" },
  { id: "weather", n: "Weather", g: "☁", c: "#8bb7e9" }
];

const D = {

  /* ---- MESSAGES ----------------------------------------------------------
     message fields:  f:"in"|"out"   t:"Today 09:12" (day word + HH:MM)
       s:"text"  |  voice:1,duration:"0:18",transcript:"…",src:"…"  |  img:"…",imgLabel:"…"  |  video:"…",duration:"0:12"
       status:"Read 09:15"  (optional; shown under the newest outgoing message, default "Delivered")
     chat fields:  id, name, avatar:"BF", img:"…", sms:true (green bubbles instead of blue)           */
  chats: [
    { id: "friend", name: "Best friend", avatar: "BF", messages: [
      { f: "in", t: "Yesterday 18:42", s: "are you still on campus?" },
      { f: "out", t: "Yesterday 18:43", s: "yeah, just leaving the library" },
      { f: "in", t: "Yesterday 18:44", s: "wait for me i'll walk with you" },
      { f: "out", t: "Yesterday 18:45", s: "okay. i'm getting coffee first" },
      { f: "in", t: "Today 09:12", s: "send me the photos when you get a chance" },
      { f: "out", t: "Today 09:14", s: "i will 😭" },
      { f: "in", t: "Today 09:16", voice: 1, duration: "0:18", transcript: "" }
    ] },
    { id: "ezra", name: "Ezra", avatar: "E", messages: [
      { f: "in", t: "Yesterday 21:08", s: "You home?" },
      { f: "out", t: "Yesterday 21:10", s: "yeah. finally" },
      { f: "in", t: "Yesterday 21:10", s: "Long day?" },
      { f: "out", t: "Yesterday 21:11", s: "long and boring. mostly boring" },
      { f: "in", t: "Today 10:03", s: "Have you eaten?" },
      { f: "out", t: "Today 10:05", s: "not yet. don't start", status: "Read 10:05" }
    ] },
    { id: "group", name: "seminar people", avatar: "4", messages: [
      { f: "in", t: "Monday 14:20", s: "does anyone have the reading list?" },
      { f: "out", t: "Monday 14:23", s: "i'll send it later" },
      { f: "in", t: "Monday 14:24", s: "thank you!!" }
    ] }
  ],

  /* ---- PHONE / FACETIME ---- kind: "Mobile" | "FaceTime" | "FaceTime Audio"; missed:true shows red */
  calls: [
    { name: "Best friend", kind: "FaceTime Audio", when: "Today, 09:12", duration: "18 min" },
    { name: "Ezra", kind: "FaceTime", when: "Yesterday, 22:16", duration: "32 min" },
    { name: "Best friend", kind: "Mobile", when: "Yesterday, 17:48", duration: "6 min" },
    { name: "University reception", kind: "Mobile", when: "Monday, 11:04", duration: "2 min" },
    { name: "Best friend", kind: "FaceTime Audio", when: "Sunday, 20:32", duration: "47 min" }
  ],

  /* ---- CONTACTS ---- add  phone:"…"  email:"…"  fav:true  img:"…"  when you have them */
  contacts: [
    { name: "Best friend", sub: "Mobile · saved contact" },
    { name: "Ezra Mikael", sub: "Mobile · saved contact" },
    { name: "University reception", sub: "Work · saved contact" }
  ],

  /* ---- PHOTOS ---- items: "Caption"  or  {name, src, date, loc, type:"video"|"screenshot", duration}   */
  photos: [
    { name: "Recents", count: 128, items: ["Coffee after class", "Library table", "Best friend laughing", "Campus building", "Dinner", "Screenshot", "Train window", "Rain on pavement", "Group photo"] },
    { name: "People", count: 34, items: ["Best friend", "Melia & best friend", "Group photo"] },
    { name: "University", count: 26, items: ["Lecture hall", "Library table", "Campus building"] },
    { name: "Screenshots", count: 41, items: ["Timetable", "Reading list", "Saved address"] },
    { name: "Videos", count: 12, items: ["Voice note video", "Dinner clip", "Campus walk"] }
  ],

  /* ---- NOTES ---- */
  notes: [
    { id: "locker", title: "locker??", folder: "Personal", date: "Today", body: "old combination doesn't work.\n\ncheck the student handbook again.\nask reception tomorrow.\n\nmaybe I wrote the number somewhere else." },
    { id: "accounts", title: "accounts — update later", folder: "Personal", date: "Monday", body: "uni email — check recovery email\ninstagram — change old password\nspotify — old one?\n\nBANKING:\nuse the banking app's official password reset. don't put the actual password here." },
    { id: "shopping", title: "shopping", folder: "Personal", date: "Sunday", body: "shampoo\nlaundry detergent\ncoffee\nbread\n\nremember tote bag" }
  ],

  /* ---- MAIL ---- optional: to:"…", unread:true */
  emails: [
    { from: "UCL Student Services", subject: "Your student timetable", date: "Today", preview: "Your timetable is available to view.", body: "Hello Melia,\n\nYour student timetable is available through the student portal. Please check the portal for room changes and updated seminar information.\n\nStudent Services" },
    { from: "Library Services", subject: "Book due date reminder", date: "Yesterday", preview: "A borrowed item is due soon.", body: "This is a reminder that one of your borrowed library items is due soon. Please check your library account for details." },
    { from: "Online Store", subject: "Your order confirmation", date: "Monday", preview: "Thank you for your order.", body: "Thank you for your order. This is a fictional sample receipt." }
  ],

  /* ---- MUSIC ---- tracks: [title, artist, length]; optional recentlyPlayed: same format */
  playlists: [
    { name: "on the way back", subtitle: "Made by Melia · 24 songs", tracks: [["Track placeholder 01", "Artist placeholder", "3:42"], ["Track placeholder 02", "Artist placeholder", "2:58"], ["Track placeholder 03", "Artist placeholder", "4:06"]] },
    { name: "don't talk to me", subtitle: "Made by Melia · 18 songs", tracks: [["Track placeholder 04", "Artist placeholder", "3:21"], ["Track placeholder 05", "Artist placeholder", "3:57"]] },
    { name: "liked songs", subtitle: "Saved music · 86 songs", tracks: [["Track placeholder 06", "Artist placeholder", "3:32"], ["Track placeholder 07", "Artist placeholder", "4:11"]] }
  ],

  /* ---- WALLET ---- Add real passes/cards here later. transactions: card:0 = index into wallet (default 0) */
  wallet: [
    { type: "Debit Card", name: "Everyday account", number: "•••• 4821", issuer: "Bank placeholder" },
    { type: "Student Pass", name: "University ID", number: "Student pass · placeholder", issuer: "University" }
  ],
  transactions: [
    { merchant: "Coffee shop", date: "Today · 08:52", amount: "£4.20", method: "Debit card" },
    { merchant: "Campus shop", date: "Yesterday · 13:18", amount: "£6.75", method: "Debit card" },
    { merchant: "Transport", date: "Monday · 09:04", amount: "£2.80", method: "Contactless" }
  ],

  /* ---- APPLE ACCOUNT / ICLOUD / FAMILY SHARING ---------------------------
     Family Sharing: each member keeps their own Apple Account. Sharing is limited to the
     features the organiser switches on (subscriptions, purchases, iCloud+ storage, location
     sharing, Screen Time…). iCloud+ storage sharing does NOT expose photos or files.
     role: "Organizer" | "Adult" | "Parent/Guardian" | "Child"  — left blank until you decide.
     features: [{name:"iCloud+", value:"Shared"}]  — left empty until you decide.                    */
  family: {
    members: [
      { name: "Melia Nadya", you: true, role: "" },
      { name: "Ezra Mikael", role: "" }
    ],
    features: []
  },
  icloud: [
    { name: "Photos", value: "On" }, { name: "Notes", value: "On" },
    { name: "iCloud Drive", value: "On" }, { name: "Messages", value: "On" }
  ],
  devices: [
    { name: "Melia's iPhone", detail: "This iPhone · Current device", status: "Current" },
    { name: "MacBook Air", detail: "Apple Account device · placeholder", status: "Known" },
    { name: "Unrecognised device", detail: "Editable story placeholder; not a real security finding", status: "Review" }
  ],

  /* ---- FIND MY ---- people: [{name, detail}]; shareMyLocation: true|false (leave undefined to hide the row) */
  findmy: { people: [] },

  /* ---- CALENDAR / REMINDERS ---- */
  calendar: [
    { day: "Today · 11:00", title: "Psychology seminar", place: "Campus · Room placeholder" },
    { day: "Today · 15:00", title: "Library study", place: "Main library" },
    { day: "Tomorrow · 10:00", title: "Lecture", place: "Campus" }
  ],
  reminders: ["Return library book", "Buy laundry detergent", "Send photos", "Check seminar reading"],

  /* ---- SAFARI ---- history entries: "Title"  or  {title, kind:"search", when:"Today"} */
  safari: ["UCL student portal", "how to reset a combination lock", "library catalogue", "train times"],
  readingList: [{ title: "Saved article", sub: "University reading placeholder" }],

  /* ---- FILES ---- "Folder"  or  {name, items:[{name, kind:"PDF", size:"1.2 MB", date:"Monday"}]} */
  files: ["Downloads", "University", "Documents", "On My iPhone", "iCloud Drive"],

  /* ---- VOICE MEMOS / PASSWORDS / MAPS ---- never put real credentials here */
  voiceMemos: [{ title: "Seminar notes", duration: "2:14", date: "Monday" }],
  passwords: [
    { site: "University account", user: "" }, { site: "Social account", user: "" }, { site: "Banking", user: "" }
  ],
  maps: [{ name: "University campus", sub: "Recent search" }, { name: "Main library", sub: "Saved place" }]
};
